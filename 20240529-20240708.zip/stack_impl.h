//------------------------------------------------------------------
// stack_impl.h
// Copyright 29.05.2024
// Author: KJR
//------------------------------------------------------------------
#ifndef STACK_IMPL_H
#define STACK_IMPL_H
#include "stack.h"

template <class T>
Stack<T>::~Stack()
{
  delete [] data;
  data = nullptr;
  size = 0;
  tos = 0;
}

// @HOME erfuellung der Rule of Five

template <class T>
T Stack<T>::pop() {
  if(!epmty()){
    --tos;
    return data[tos];
  } else{
    throw std::runtime_error("Error: Stack ist leer");
  }
}


#endif // STACK_IMPL_H
