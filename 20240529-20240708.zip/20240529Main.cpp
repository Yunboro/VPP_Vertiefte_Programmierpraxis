//------------------------------------------------------------------
// 20240529Main.cpp
// Copyright 28.05.2024
// Author: KJR
//------------------------------------------------------------------
#include <iostream>
#include <cstring>
#include <complex>
#include <fstream>
#include <string>
//#include "stack.h"
#include "stack_impl.h"

using std::cout;
using std::endl;

void dateiAusgabe() {
  std::string fname = "jaeger.txt";
  std::ofstream out{fname};
  if(!out.is_open()) {
    throw std::runtime_error("Datei " + fname + " kann nicht geoeffnet werden");
  }
  for(int i = 10; i > 0; --i){
    out << i << " Jaegerlein" << endl;
  }
  if(out.is_open()) {
    out.close();
  }
}




/*
// Funktionstemplates
template <class T>
void swap(T& x, T& y) {
  T temp = x;
  x = y;
  y = temp;
}

template <typename T>
bool less(T x, T y) { return x < y; }

// Template Spezialisierung fuer const char*
template <>
bool less(const char* x, const char* y) {
  return std::strcmp(x, y) < 0;
}

template <class T>
void bubbleSort(T* v, int n) {
  for (int i = 1; i < n; ++i) {
    for (int j = 0; j < n - i; ++j) {
      if (less(v[j + 1], v[j])) {
        swap(v[j], v[j + 1]);
      }
    }
  }
}

template <class T>
void printVec(T* v, int n) {
  for (int i = 0; i < n; ++i) {
    cout << v[i] << endl;
  }
}
*/
int main()
{
  
  dateiAusgabe();
  /*
  Stack<int> is{10};
  is.push(1);
  is.push(2);
  is.push(3);
  is.push(4);
  cout << is.pop() << endl;
  
  cout << is << endl;
  
  Stack<double> ds{3};
  for(int i = 1; i <= 4; ++i){
   try {
    ds.push(static_cast<double>(i));
   } catch (const std::runtime_error& e) {
      std::cerr << e.what() << endl;
   } catch(...) {
     std::cerr << "Irgend ein anderer Fehler" << endl;
   } 
  }    
  cout << ds << endl;
  */
  
  
  /*
  const char* n1 = "Xaver";
  const char* n2 = "Anton";
  cout << std::boolalpha << less(n1, n2) << endl;

  // Endlose Fehlermeldungen bei Templates 
  //std::complex<int> z1{1, 3};
  //std::complex<int> z2{2, 5};
  //cout << std::boolalpha << less(z1, z2) << endl; 
  
  int iv[5] = {10, 3, 5, 2, 7};
  bubbleSort(iv, 5);
  printVec(iv, 5);
  
  double dv[5] = {10, 3, 5, 2, 7};
  bubbleSort(dv, 5);
  printVec(dv, 5);
  
  const char* namen[4]{"Xaver", "Anton", "Ida", "Richard"};
  bubbleSort(namen, 4);
  printVec(namen, 4);
  */
  return 0;
}
