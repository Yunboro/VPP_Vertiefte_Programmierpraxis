//------------------------------------------------------------------
// Stack
// Copyright 29.05.2024
// Author: KJR
//------------------------------------------------------------------
#ifndef STACK_H
#define STACK_H
#include <iostream>
#include <stdexcept>

template <class T>
class Stack
{
 private:
  int size;
  int tos;
  T* data;
 public:
  Stack(int s) : size{s}, tos{0},
                 data{new T[size]} {}
  
  void push(T element) {
    if (tos < size) {
      data[tos] = element;
      ++tos;
    } else {
      throw std::runtime_error("Error: Stack ist voll");
    }
  }
  
  bool epmty() const {
    return tos == 0;
  }
  T pop();
  T top() const {
    if(!epmty()){
      return data[tos-1];
    } else{
      throw std::runtime_error("Error: Stack ist leer");
    }
  }
  void output(std::ostream& os) const {
    for(int i = 0; i < tos; ++i) {
      if(i != 0){
        os << ", ";
      }
      os << data[i];
    }
  }
  ~Stack();
};
/*
// kann auch in die stack_impl.h Datei ausgelagert werden

template <class T>
Stack<T>::~Stack()
{
  delete [] data;
  data = nullptr;
  size = 0;
  tos = 0;
}

// @HOME Erfuellung der Rule of Five

template <class T>
T Stack<T>::pop() {
  if(!epmty()){
    --tos;
    return data[tos];
  } else{
    throw std::runtime_error("Error: Stack ist leer");
  }
}

*/

// Ueberladung des Ausgabe-Operators ist jetzt ein Funktions-Template
template <class T>
inline std::ostream& operator<<(std::ostream& os, const Stack<T>& s) {
  s.output(os);
  return os;
}

#endif // STACK_H
