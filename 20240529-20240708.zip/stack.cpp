//------------------------------------------------------------------
// Stack
// Copyright 29.05.2024
// Author: KJR
//------------------------------------------------------------------
#include "stack.h"

// Imlementierung in einer cpp-Datei erfordert
// das explizite Instanzieren s. u.
// Nachteil: man muss als Entwickler einer Klasse vorausahnen
// fuer welche konkreten Typen fuer den Typparameter die Klasse
// benoetigt wird

template <class T>
Stack<T>::~Stack()
{
  delete [] data;
  data = nullptr;
  size = 0;
  tos = 0;
}

template <class T>
T Stack<T>::pop() {
  if(!epmty()){
    --tos;
    return data[tos];
  } else{
    throw std::runtime_error("Error: Stack ist leer");
  }
}

// explizites Instanzieren
template class Stack<int>;

