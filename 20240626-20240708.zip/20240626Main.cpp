//------------------------------------------------------------------
// 20240624Main.cpp
// Copyright 26.06.2024
// Author: KJR
//------------------------------------------------------------------

#include <iostream>
#include <stdexcept>
#include <vector>
#include <fstream>
#include <algorithm>
#include <functional>
#include <numeric>  // fuer iota

using std::cout;
using std::endl;



//================================================================
// 1) Aufgabe Klassen-Template StackL
// a) Implementierung der Struktur Teller
template <class T>
struct Teller{
  T data;
  Teller* next;
};

// b) Implementierung von Klasse StackL
template <class T>
class StackL {
 private:
  int n;
  Teller<T>* tos;
  
  void clear() {
    while (tos != nullptr) {
      Teller<T>* tmp = tos->next;
      delete tos;
      tos = tmp;
    }
    n = 0;
  }
  
  void copyData(const StackL& rhs) {
    StackL tmp;
    Teller<T>* t = rhs.tos;
    while( t != nullptr){
      tmp.push(t->data);
      t = t->next;
    }
    
    while(!tmp.empty()){
      StackL<T>::push(tmp.pop());
    }
  }
 public:
  StackL() : n{0}, tos{nullptr} {}
  virtual void push(T element) {
    Teller<T>* tNeu = new Teller<T>;
    tNeu->data = element;
    if(tos == nullptr){
      // tos = tNeu;
      // tos->next = nullptr;
      tNeu->next =nullptr;
    } else {
      tNeu->next = tos;
      // tos = tNeu;
    }
    tos = tNeu;
    ++n;
  }
  bool empty() const {
    return tos == nullptr;
  }
  virtual T pop() {
    if(empty()){
      throw std::runtime_error("ERROR Stack ist leer");
    }
    Teller<T>* tDel = tos;
    T erg = tDel->data;
    tos = tos->next;
    delete tDel;
    --n;
    return erg;
  }
  T top() const {
    if(empty()){
      throw std::runtime_error("ERROR Stack ist leer");
    }
    return tos->data;
  }
  void output(std::ostream& os) const {
    os << "--------------------" << endl;
    Teller<T>* t = tos;
    while(t != nullptr){
      os << t->data << endl;
      t = t->next;
    }
    os << "--------------------" << endl;
  }
  StackL(const StackL& rhs) : n{0}, tos{nullptr} {
    copyData(rhs);
  }
  StackL& operator=(const StackL& rhs) {
    if(this != &rhs){
      clear();
      copyData(rhs);
    }
    return *this;
  }
  virtual ~StackL();
};

// Implementierung des Destruktors
// ausserhalb der Klasse
template <typename T>
StackL<T>::~StackL<T>() {
  clear();
}

//----------------------------------------------------------
// c) Ueberladen des Ausgabe-Operators
template <class T>
inline std::ostream& operator<<(std::ostream& os, const StackL<T>& s) {
  s.output(os);
  return os;
} 

// Test

void a01() {
  // Instanzieren von is1 mit T = int
  StackL<int> is1;

  // Ablegen der Werte 1, 2, 3, 4
  is1.push(1);
  is1.push(2);
  is1.push(3);
  is1.push(4);
  
  cout << is1 << endl;
  
  // Copy-Konstruktor
  StackL<int> is2{is1};
  cout << is2 << endl;

  // Copy Zuweisung
  StackL<int> is3;
  is3 = is1;
  cout << is3 << endl;

  // Test von pop()
  cout << is1.pop() << endl;
  cout << is1 << endl;
}

//===============================================================
// 2) Aufgabe Vererbung
//    Aenderungen am Stack durch push() oder pop() werden
//    in einem Logfile "logN.txt" gelogged, wobei N die
//    Anzahl der Objekte vom Typ StackLWithLogging, die zur
//    Laufzeit existieren, angibt.
//
//    geerbte Member-Funktionen entweder Aufruf mit this
//    oder mit voll qualifizierten Namen
template <class T>
class StackWithLogging  : public StackL<T> {
 private:
  static int counter;
  std::ofstream logFile;
 public:
  StackWithLogging() {
    ++counter;
    std::string fname ="log" + std::to_string(counter) + ".log";
    logFile.open(fname);
    if(!logFile.is_open()) {
      throw std::fstream::failure("Error oeffnen der Datei: " + fname);
    }
  }
  void push(T element) override {
    StackL<T>::push(element);
    logFile << "push von " << element << endl;
    // Aufruf einer geerbten Methode
    this->output(logFile);
  }
  T pop() override {
    T erg = StackL<T>::pop();
    logFile << "pop von " << erg << endl;
    // Aufruf einer geerbten Methode
    StackL<T>::output(logFile);
    return erg;
  }
  ~StackWithLogging() {
    --counter;
    if(logFile.is_open()){
      logFile.close();
    }
  }  
 
};

// Initialisierung der Statischen Variable
// ausserhalb der Klasse
template <class T>
int StackWithLogging<T>::counter = 0;

// Test mit Abfangen der Exceptions
// zuerst in falscher Reihenfolge
// Seit C++11: exception <- runtime_error <- system_error <- ios_base::failure
void a02() {
  try{
    StackWithLogging<double> ds;
    ds.push(1.0);
    ds.push(2.0);
    ds.push(3.0);
    cout << ds.pop() << endl;
  } catch (const std::fstream::failure& e) {
    cout << e.what() << endl;
  } catch (const std::runtime_error& e) {
     cout << e.what() << endl;
  }
}

//=======================================================
// 3) Aufgabe (Funktionale Programmierung)
//    hoehere Funktion
//    IT myReverse_if(IT b, IT e, P p)
//    Elemente fuer die das Praedikat p
//    erfuellt ist werden im Bereich [b, e)
//    des Containers in der Reihenfolge umgedreht
//    Rueckgabe ist ein Iterator der auf das neue
//    Ende verweist

// Funktion Hoeherer Ordnung
// Trick Praedikat ist weiterer Typ-Parameter
template <class IT, class P>
IT myReverse_if(IT b, IT e, P p) {
  StackL<typename IT::value_type> s;
  auto it = b;
  while(it != e){
    if(p(*it)){
      s.push(*it);
    }
    ++it;
  }
  it = b;
  while(!s.empty()){
    *it = s.pop();
    ++it;
  }
  return it;
}

// Peardikat: nur Elemente e, fuer die gilt
//  e < 5
// sind zu beruecksichtigen
// First class Functions
// a) als Funktion lt5 oder (Funktions-Pointer)
bool lt5(int i) {
  return i < 5;
}

// b) Als Funktor (Praedikat) Lt5
class Lt5 {
 public:
  bool operator()(int i) const {
    return i < 5;
  }
};

void a03() {
  cout << "====== myReverse ====" << endl;
  std::vector<int> iv(7, 0);
  std::iota(iv.begin(), iv.end(), 1);

  // Ausgabe mit Bereichsbasierter Schleife
  for(auto e: iv){
    cout << e << endl;
  }

  // a) Funktionspointer
  //bool (*fp)(int) = lt5;
  //auto itEnd =  myReverse_if(iv.begin(), iv.end(), fp);

  // b) std::function
  //std::function<bool(int)> fc = fp;
  //auto itEnd =  myReverse_if(iv.begin(), iv.end(), fc);
  
  // c) Funktor
  //Lt5 functor_lt5;
  //auto itEnd =  myReverse_if(iv.begin(), iv.end(), functor_lt5); 
  // d) Lambda-Ausdruck
  auto itEnd =  myReverse_if(iv.begin(), iv.end(),
                            [](int i){return i < 5;}); 
  
  // Nicht mehr benoetigte Elemente Loeschen
  // mit Methode erase(b, e)
  iv.erase(itEnd, iv.end());
  
  cout << "============" << endl;
  for (const auto& e: iv){
    cout << e << endl;
  }
}

int main()
{
  //a01();
  //a02();
  a03();
  return 0;
}
