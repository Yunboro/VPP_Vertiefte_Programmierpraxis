//------------------------------------------------------------------
// 20240612Main.cpp
// Copyright 12.06.2024
// Author: KJR
//------------------------------------------------------------------
#include <iostream>
#include <fstream>
#include <stdexcept>
#include <string>
#include <vector>
#include <cstdlib>
#include <set>
#include <map>
#include <utility>  // fuer pair
#include <algorithm>
#include <functional>

#include "buch.h"

using std::cout;
using std::endl;

//typedef std::vector<Buch> TBib;
// neu fuer C++
using TBib = std::vector<Buch>;

// Aufgabe 4) Skript S. 353
Buch extractBuch(const std::string& zeile) {
  size_t p1, p2, p3, jahr, bw;
  std::string autor, titel;
  p1 = zeile.find(';');
  if (p1 == std::string::npos) {
    throw std::runtime_error("kein Semikolon fuer p1");
  }
  
  p2 = zeile.find(';', p1+1);
  if (p2 == std::string::npos) {
    throw std::runtime_error("kein Semikolon fuer p2");
  }
  
  p3 = zeile.find(';', p2+1);
  if (p3 == std::string::npos) {
    throw std::runtime_error("kein Semikolon fuer p3");
  }
  // laenge = p1 - 1 - 0 + 1 = p1
  autor = zeile.substr(0, p1);
  
  // laenge = p2 - 1 - (p1 + 1) + 1 = p2 - p1 - 1
  titel = zeile.substr(p1+1, p2 - p1 - 1);
  // laenge = p3 - 1 - (p2 + 1) + 1 = p3 - p2 - 1
  jahr = static_cast<size_t>(std::atoi(zeile.substr(p2+1, p3 - p2 - 1).c_str()));
  // laenge = zeile.size()-1 - (p3+1) + 1 = zeile.size() - p3 - 1
  bw = static_cast<size_t>(
      std::atoi(zeile.substr(p3+1, zeile.size() - p3  - 1).c_str()));
  // cout << autor << ", " << titel << ", " << jahr << ", " << bw << endl;
  Buch b{autor, titel, jahr, bw};
  return b;
  
}

// 5) Aufgabe Skript S. 353
void readCSV(const std::string& fname, TBib& tbib) {
  std::ifstream in{fname};
  
  if (!in.is_open()){
    throw std::runtime_error("ERROR Datei " + fname + "kann nicht geoffnet weden");
  }
  std::string zeile;
  while (in.good()) {
    std::getline(in, zeile);
    if (in.good()) {
      //cout << zeile << endl;
      tbib.push_back(extractBuch(zeile));
    } else if (in.eof()){
      break;
    }
  }
  
}

// 6) Aufgabe Skript S. 353
void ausgabeAutorenOhneMehrfachnennung(const TBib& tbib) {
  std::set<std::string> my_set;
  for(auto const& e: tbib){
    my_set.insert(e.getAutor());
  }
  for(auto const&e: my_set){
    cout << e << endl;
  }
}

// Aufgabe 1) Skript S. 353
void aFormatiertesLesen() {
  std::string fname = "jaeger.txt";
  std::ifstream in{fname};
  
  if (!in.is_open()){
    throw std::runtime_error("ERROR Datei " + fname + "kann nicht geoffnet weden");
  }
  
  int anzahl;
  std::string wort;
  while (in.good()) {
    in >> anzahl >> wort;
    if (in.good()) {
      cout << anzahl << ", " << wort << endl;
    } else if (in.eof()){
      break;
    } else if (in.fail()){
      in.clear();
      std::string muell;
      in >> muell;
      std::cerr << "ungueltiges Zeichen: " << muell << endl;
    }
  }

}

// Vergleichsfunktion fuer das Sortieren
bool greater(const Buch& a, const Buch& b) {
  return a.getBewertung() > b.getBewertung();
}

// Vergleichsfunktion als Funktor
struct Greater {
  bool operator()(const Buch& a, const Buch& b) const {
    return a.getBewertung() > b.getBewertung();
  }
};


int main()
{
  // 1) Aufgabe 
  //aFormatiertesLesen() ;
  
  std::string fname = "csWithRating.txt";
  TBib tbib;
  
  // 5) Aufgabe
  readCSV(fname, tbib);
  
  // Alle Autor Namen ausgeben
  //for(auto const& e: tbib){
  //  cout << e.getAutor() << endl;
  //}
  //auto it = tbib.begin();
  //while (it != tbib.end()){
  //  cout << (*it).getAutor() << endl;
  //  ++it;
  //}
  // 6) Aufgabe
  //ausgabeAutorenOhneMehrfachnennung(tbib);
  
  // 7) Aufgabe
  std::map<size_t, TBib> bibNachJahr;
  for(auto const& e: tbib) {
    bibNachJahr[e.getJahr()].push_back(e);
  }
  //for(auto paar: bibNachJahr){
  //  cout << paar.first << " : " << paar.second.size() << endl;
  //}
  
  // 8) Aufgabe Buecher fuer das Jahr 2015 nach absteigender Bewertung sortieren
  // Als Vergleichsfunktion ein Funktionspointer
  // bool (*fp)(const Buch&, const Buch&) = greater;
  // std::sort(bibNachJahr[2015].begin(), bibNachJahr[2015].end(), greater);
  // std::sort(bibNachJahr[2015].begin(), bibNachJahr[2015].end(), fp);
  
  // mittels std::function
  //std::function<bool(const Buch&, const Buch&)> fc = greater;
  //std::sort(bibNachJahr[2015].begin(), bibNachJahr[2015].end(), fc);
  
  // Mittels Funktionsobjekt (Funktor)
  // Greater g;
  //std::sort(bibNachJahr[2015].begin(), bibNachJahr[2015].end(), g);
  //std::function<bool(const Buch&, const Buch&)> fc = g;
  //std::sort(bibNachJahr[2015].begin(), bibNachJahr[2015].end(), fc);
  
  // Mittels Lambda Ausdruck
  //std::sort(bibNachJahr[2015].begin(),
  //          bibNachJahr[2015].end(),
  //          [](const Buch&a, const Buch&b){
  //            return a.getBewertung() > b.getBewertung();
  //          });
  std::function<bool(const Buch&, const Buch&)> fc =
      [](const Buch&a, const Buch&b){
    return a.getBewertung() > b.getBewertung();
  };
  std::sort(bibNachJahr[2015].begin(), bibNachJahr[2015].end(), fc);
  for(auto const& e: bibNachJahr[2015]) {
    e.output(cout);
  }
  //cout << bibNachJahr[9999].size() << endl;

  return 0;
}
