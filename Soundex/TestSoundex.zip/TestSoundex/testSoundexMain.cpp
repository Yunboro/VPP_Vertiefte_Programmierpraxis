//---------------------------------------------------------------------
// testSoundexMain.cpp
// Copyright 18.09.2020
// Author: KJR
//---------------------------------------------------------------------
#include "tst_soundex.h"

#include <gtest/gtest.h>

int main(int argc, char *argv[])
{
  ::testing::InitGoogleTest(&argc, argv);
  return RUN_ALL_TESTS();
}
